title: testing

KAWAII MONO `wow`
kawaii mono
^font name by Paring
^font glyph by qwreey
OPEN FONT LICENCE

모던한 폰트
```js
console.log({
	qwreey: "I made this font!",
	paring: "just CUTE person"
});
let array = ["Paring","Qwreey","ChocoSwi"];
// WOAAAAwo!
if (!true) {
	console.log("Hello world");
}
```

```text
--------------------------
       KAWAII MONO
        by Qwreey
ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz
~!@#$%&? ;:., `'" ()[]{}<>
	  0123456789 _-=+^*\|/
--------------------------
```
?=
```html
<html>
    <head>
        <title>The true is</title>
    </head>
    <body>
        <p>HTML IS NOT CUTE</p>
    </body>
</html>
```

```css
*{
    color: black;
}
#mybutton {
    margin-top: 123px;
}
/* wow */
.testButton {
    padding: 45px 67px 89px 0;
}
```

```md
# Markdown!
written by @qwreey
> Quotes

| 1 | 2 | 3 |
|---|---|---|
| a | b | c |
```

```python
# comments
@testing
def helloworld():
    return "awawaawaw"
print(helloworld())
print(2**5,2+5,2-5)
```

```lua
local myClass = {};
myClass.__index = myClass;

function myClass:print()
    print(
        ("my name is %s")
        :format(self.name));
end

local this = setmetatable(
    myClass,{name = "Hello world"});
this:print();
```

```c
#include <stdio.h>

int main() {
    int a = 0;
    scanf("%d",&a);
    printf("Hello world %d",1234567890-a);
    return 0;
}
```

```javascript
let name = "qwreey";
let array = [
    "myArray",`my name is ${name}`
    '`~!@#$%^&*()_+{}=-[];:.>/?,<'
];
console.log(array[1]);

async function main() {
    let data =
        await fetch("https://google.com");
    console.log(data);
}
```

```go
package main

import "fmt"

func main() {
    fmt.Printn("Hello world~!")
}
```

```sh
sudo rm -rf /
echo "WOW!"
echo "qwreey" > myName.txt
cat "$(pwd)/myName.txt"
```

```make
build:
    yarn build
copy:
    cp dist/myProgram /usr/bin
install: build copy
```

*asdfasdf
	    indents


this font is not cute

select qwreey from qwreey


ocaenvxzwrum ygpq ijt fkl

async function test
	await test

this font is not not cute


int main
	printf  Hello world

ouo opo 
oOo owo
Waaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
wayyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy
HOOOOOOOOOOOOOOOOOOOOOOooooooOoOoOooooooooo
this is much better then i think owo






Qwreey != Kawaii
