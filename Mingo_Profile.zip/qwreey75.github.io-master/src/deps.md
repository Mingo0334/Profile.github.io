title: 이 웹사이트가 사용한 기술

# THANKS TO . . .

## 사용 라이브러리

### Mkdocs - Mkdocs Material
코드의 일부분이 프로젝트 일부분으로 사용되었습니다  

### Python Markdown
Markdown 의 HTML 빌드를 위해서 사용되었습니다  

### Luvit (Lua + uvlib + luajit)
페이지 빌드, python 관리, 변수 관리, css-js 빌딩 등을 위해 사용되었습니다   
내부 모듈인 fs, pretty-print 를 사용했습니다

### MyXML
구분 분석을 통해서 META 데이터를 읽어오기 위해 사용됩니다
또한 이것을 이용해 HTML MINIFY 를 수행하기도 합니다
깃허브 리포 : https://github.com/qwreey75/myXml.lua
