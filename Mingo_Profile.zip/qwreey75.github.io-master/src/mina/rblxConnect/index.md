title: 미나블록스 사용설명서

# 미나블록스 사용설명서
<br>
<div align=center>
<img src="2022-07-31-09-04-39.png">
</div>

<div align=center markdown>간단하지만 강력한. 현대적인 유저관리 방법 **Minablox**</div>
<br>
<div align=center markdown>
[시작하기](/mina/rblxConnect/gettingstarted "기초 안내로 이동합니다"){ .md-button }
</div>
<br>

<div align=center>
<h2 style="width: fit-content; margin: 0.6em;">디스코드에서. 게임 참가없이. 명령어 하나로 바로 유저 관리하는법</h2>
<img src="2022-07-31-09-54-59.png">
</div>

<div style="display:flex; justify-content: center; width: 100%;" markdown>
<div align=left markdown>
<h2 style="width: fit-content; margin: 0.6em;">지금 시작해볼까요?</h2>

1. [시작하기 (API 등록법 / 설정법)](/mina/rblxConnect/gettingstarted) <br>
2. [블랙리스트(밴) 사용법](/mina/rblxConnect/blacklist) <br>
3. [화이트리스트(일부허용) 사용법](/mina/rblxConnect/whitelist) <br>
4. [모두허용 모드 사용법](/mina/rblxConnect/freepass) <br>
5. [사용자정의 문의 링크 사용법](/mina/rblxConnect/link) <br>
</div>
</div>
