
let openButton = document.querySelector("#menuOpenButton")
let menu = document.querySelector("#floatingMenu")

openButton.addEventListener("onclick",() => {
    openButton.classList.toggle("open")
})
